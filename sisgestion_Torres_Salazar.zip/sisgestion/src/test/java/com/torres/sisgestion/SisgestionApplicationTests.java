package com.torres.sisgestion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SisgestionApplicationTests {

	@Test
	void contextLoads() {
	}

}
